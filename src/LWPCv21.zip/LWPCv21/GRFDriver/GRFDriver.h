/*------------------------
      Driver.H header file
  ------------------------*/

#define IDM_NEW      1
#define IDM_REDRAW   2
#define IDM_GO       3
#define IDM_PRINT    4
#define IDM_OPT1     5
#define IDM_OPT2     6
#define IDM_EXIT     7
#define IDM_HELP    40
#define IDM_ABOUT   41
